var GRNN = function(layers) {
	this.layers = layers;
	this.activations = layers.slice(1,Infinity).map(function(size){return new Float32Array(size);});
	this.TrainActivations = layers.slice(1,Infinity).map(function(size){return new Float32Array(size);});
	this.WaB = layers.slice(1,Infinity).map(function(size,idx){return {W:new Array(size).fill(0).map(function(){return new Float32Array(layers[idx]+size)}),B:new Float32Array(size)};});
	this.WaBDeltaPrev = layers.slice(1,Infinity).map(function(size,idx){return {W:new Array(size).fill(0).map(function(){return new Float32Array(layers[idx]+size)}),B:new Float32Array(size)};});
	this.randomize = function(wl,bl) {
		if (!wl && wl !== 0) {
			wl = 1;
		}
		if (!bl && bl !== 0) {
			bl = 1;
		}
		for (var i=1; i<this.layers.length; i++) {
			var m = wl/Math.sqrt(this.layers[i-1]+this.layers[i]);
			//var m = ml/Math.sqrt(this.layers[i-1]+1);
			for (var j=0; j<this.layers[i]; j++) {
				this.WaB[i-1].B[j] = this.randn()*bl;
				for (var k=0; k<this.layers[i-1]+this.layers[i]; k++) {
				//for (var k=0; k<this.layers[i-1]; k++) {
					this.WaB[i-1].W[j][k] = this.randn()*m;
					//if (k >= this.layers[i-1]) {
						//this.WaB[i-1].W[j][k] = this.randn()*m*2;
					//} else {
						//this.WaB[i-1].W[j][k] = this.randn()*m*0.5;
					//}
				}
			}
		}
	}
	this.randn = function() {
		//return Math.random()-0.5;
		var u = 0, v = 0;
		while(u === 0) u = Math.random();
		while(v === 0) v = Math.random();
		return Math.sqrt( -2.0 * Math.log( u ) ) * Math.cos( 2.0 * Math.PI * v );
	}
	this.clamp = function(v,mn,mx) {
		return Math.max(Math.min(v,mx),mn);
	}
	this.lerp = function(a,b,x) {
		return ((b-a)*x)+a;
	}
	this.limit = function(x,y) {
		//return ((4*y)/(Math.exp(-x/y)+1))-(2*y);
		
		x /= y;
		if (Math.abs(x) < Math.PI/2) {
			return Math.sin(x)*y;
		} else {
			return Math.sign(x)*y;
		}
	}
	this.cycle = function(inp) {
		var self = this;
		//var after = new Float64Array(this.size);
		//new Float64Array(this.WaB.B)
		var after = [];
		var drivresult = [];
		var prevLayer = inp;
		for (var i=0; i<this.WaB.length; i++) {
			var nextLayer = new Float32Array(this.WaB[i].B);
			var linresult = new Float32Array(this.layers[i+1]);
			for (var j=0; j<nextLayer.length; j++) {
				for (var k=0; k<this.layers[i]; k++) {
					nextLayer[j] += this.WaB[i].W[j][k]*prevLayer[k];
					//nextLayer[j] += this.WaB[i].W[j][nextLayer.length+k]*prevLayer[k];
				}
				for (var k=0; k<nextLayer.length; k++) {
					nextLayer[j] += this.WaB[i].W[j][this.layers[i]+k]*this.activations[i][k];
					//nextLayer[j] += this.WaB[i].W[j][k]*this.activations[i][k];
				}
				//linresult[j] = this.activationFunctionDerivitive(nextLayer[j]);
				nextLayer[j] = this.activationFunction(nextLayer[j]);
				linresult[j] = this.activationFunctionInverseThenDerivitive(nextLayer[j]);
			}
			after.push(nextLayer);
			drivresult.push(linresult);
			prevLayer = nextLayer;
		}
		//this.activations = after.map(function(xin){return self.activationFunction(xin)});
		this.activations = after;
		return drivresult;
	}
	this.train = function(inp,outp,len,loops,d,momentum) {
		var self = this;
		var Accuricy = 0;
		var AccuricyL = 0;
		var currentAct = this.activations;
		this.activations = this.TrainActivations;
		var WaBdelta = layers.slice(1,Infinity).map(function(size,idx){return {W:new Array(size).fill(0).map(function(){return new Float32Array(layers[idx]+size).fill(0)}),B:new Float32Array(size).fill(0)};});
		for (var h=0; h<loops; h++) {
			var linlayers = [];
			var actlayers = [];
			for (var j=0; j<inp.length; j++) {
				linlayers.push(this.cycle(inp[j]));
				//this.cycle(inp[j]);
				actlayers.push(this.activations);
				//linlayers.push(this.cycle(inp[j]));
			}
			//console.log(linlayers);
			//var delta = new Float64Array(this.layers[this.layers.length-1]);
			var DeltaLayers = this.layers.slice(1,Infinity).map(function(size){return new Float32Array(size);});
			for (var i=actlayers.length-1; i>=len; i--) {
				var delta = new Float32Array(this.layers[this.layers.length-1]);
				var amount = 0;
				for (var k=0; k<this.layers[this.layers.length-1]; k++) {
					var op = (outp[i-len][k]-actlayers[i][actlayers[i].length-1][k]);
					//var op = (actlayers[i][actlayers[i].length-1][k]-outp[i-len][k]);
					//console.log(actlayers[i][j]);
					if (op || op == 0) {
						//amount += op*op;
						amount += Math.abs(op);
						//AccuricyL++;
						delta[k] += op*linlayers[i][linlayers[i].length-1][k];
					}
				}
				//amount /= Math.sqrt(linlayers[i][linlayers[i].length-1].length);
				amount /= linlayers[i][linlayers[i].length-1].length;
				Accuricy += amount;
				AccuricyL++;
				for (var j=this.layers.length-2; j>0; j--) {
					var NewDelta = new Float32Array(this.layers[j]);
					var NewDelta2 = new Float32Array(this.layers[j+1]);
					var total = 0;
					for (var k=0; k<delta.length; k++) {
						WaBdelta[j].B[k] += delta[k];
						for (var n=0; n<NewDelta.length; n++) {
							WaBdelta[j].W[k][n] += actlayers[i][j-1][n]*delta[k];
						}
						for (var n=0; n<delta.length; n++) {
							WaBdelta[j].W[k][NewDelta.length+n] += actlayers[i-1][j][n]*delta[k];
						}
					}
					for (var k=0; k<NewDelta.length; k++) {
						for (var n=0; n<delta.length; n++) {
							NewDelta[k] += this.WaB[j].W[n][k]*delta[n];
						}
						NewDelta[k] += DeltaLayers[j-1][k];
						NewDelta[k] *= linlayers[i][j-1][k];
						total += Math.abs(NewDelta[k]);
					}
					for (var k=0; k<NewDelta2.length; k++) {
						for (var n=0; n<delta.length; n++) {
							NewDelta2[k] += this.WaB[j].W[n][NewDelta.length+k]*delta[n];
						}
						//NewDelta2[k] *= linlayers[i][j][k];
					}
					DeltaLayers[j] = NewDelta2;
					delta = NewDelta;
					//if (total) {
						//delta = NewDelta.map(function(xin){return xin/total});
					//} else {
						//delta = NewDelta.fill(0);
					//}
				}
				for (var k=0; k<delta.length; k++) {
					WaBdelta[0].B[k] += delta[k];
					for (var n=0; n<delta.length; n++) {
						WaBdelta[0].W[k][inp[i].length+n] += actlayers[i-1][0][n]*delta[k];
					}
					for (var n=0; n<inp[i].length; n++) {
						WaBdelta[0].W[k][n] += inp[i][n]*delta[k];
					}
				}
			}
			//var m = d/(inp.length*(inp.length+1));
		}
		var m = d/(loops*inp.length);
		for (var i=0; i<WaBdelta.length; i++) {
			//var m = d/(inp.length);
			for (var j=0; j<WaBdelta[i].B.length; j++) {
				//WaBdelta[i].B[j] *= m;
				//WaBdelta[i].B[j] += this.WaBDeltaPrev[i].B[j]*momentum;
				//this.WaB[i].B[j] += WaBdelta[i].B[j];
				WaBdelta[i].B[j] = this.lerp(WaBdelta[i].B[j]*m,this.WaBDeltaPrev[i].B[j],momentum);
				this.WaB[i].B[j] = this.clamp(this.WaB[i].B[j]+WaBdelta[i].B[j],-8,8);
			}
			//m = d/(loops*inp.length*Math.sqrt(WaBdelta[i].W[0].length));
			//m = d/(inp.length*loops);
			for (var j=0; j<WaBdelta[i].W.length; j++) {
				for (var k=0; k<WaBdelta[i].W[j].length; k++) {
					//if (k < this.layers[i]) {
						//WaBdelta[i].W[j][k] *= m;
						//WaBdelta[i].W[j][k] += this.WaBDeltaPrev[i].W[j][k]*momentum;
						WaBdelta[i].W[j][k] = this.lerp(WaBdelta[i].W[j][k]*m,this.WaBDeltaPrev[i].W[j][k],momentum);
						//this.WaB[i].W[j][k] += WaBdelta[i].W[j][k];
						this.WaB[i].W[j][k] = this.clamp(this.WaB[i].W[j][k]+WaBdelta[i].W[j][k],-8,8);
					//} else {
						//WaBdelta[i].W[j][k] = 0;
						//this.WaB[i].W[j][k] = 0;
					//}
				}
			}
		}
		this.WaBDeltaPrev = WaBdelta;
		this.TrainActivations = this.activations;
		this.activations = currentAct;
		return {Accuracy:1-((Accuricy)/(AccuricyL)),WaBDelta:WaBdelta};
	}
	this.activationFunction = function(x) {
		return Math.tanh(x);
		
		//return (2*x)/((x*x)+1);
		
		//return Math.sin(x);
		
		//x = Math.exp(-2*x);
		//return (1-x)/(1+x);
		
		//return x;
		//return Math.max(x,-1);
	}
	this.activationFunctionDerivitive = function(x) {
		return Math.atanh(x);
		
		//x = (x*x)+1;
		//return (2*(2-x))/(x*x);
		
		//return Math.cos(x);
		
		//return (2*(1-(x*x)))/(((x*x)+1)**2);
		//x = this.activationFunction(x);
		//return (1+x)*(1-x);
		
		//return (this.activationFunction(x+0.001)-this.activationFunction(x-0.001))/0.002;
		//x = Math.exp(-2*x)+1;
		//return 4*(x-1)/(x*x);
		//return 1;
		//return x > -1 ? 1:0;
	}
	this.activationFunctionInverseThenDerivitive = function(x) {
		return 1-(x*x);
	}
}