var ReconstructionAI = function(opts){
    this.opts = opts;
    this.gpu = new GPU({ mode: 'gpu' });
    //.setTactic('precision')
    this.gpu.addNativeFunction('dt',`float dt(vec3 a, vec3 b){
        return dot(a,b);
    }`);
    // this.gpu.addNativeFunction('d',`float d(vec4 a, vec4 b){
    //     return dot(a.xyz,b.xyz);
    // }`);
    this.gpu.addNativeFunction('mul',`vec3 mul(vec3 a, float b){
        return a*b;
    }`);
    this.gpu.addNativeFunction('mult3',`vec3 mult3(vec3 a, vec3 b){
        return a*b;
    }`);
    this.gpu.addNativeFunction('mul4',`vec4 mul4(vec4 a, float b){
        return a*b;
    }`);
    this.gpu.addNativeFunction('ad',`vec3 ad(vec3 a, vec3 b){
        return a+b;
    }`);
    this.gpu.addNativeFunction('sub3',`vec3 sub3(vec3 a, vec3 b){
        return a-b;
    }`);
    this.gpu.addNativeFunction('ad4',`vec4 ad4(vec4 a, vec4 b){
        return a+b;
    }`);
    this.gpu.addNativeFunction('act',`vec3 act(vec3 a){
        a = exp(-2.0*a);
        return (1.0-a)/(1.0+a);

        // return tanh(a);

        // return sin(a);
    }`);
    this.gpu.addNativeFunction('act1',`float act1(float a){
        a = exp(-2.0*a);
        return (1.0-a)/(1.0+a);

        // return tanh(a);

        // return sin(a);
    }`);
    this.gpu.addNativeFunction('driv',`vec3 driv(vec3 a){
        return (1.0-(a*a));
    }`);
    this.gpu.addNativeFunction('driv1',`float driv1(float a){
        return (1.0-(a*a));
    }`);
    this.blankTex = this.gpu.createKernel(function(){
        return [0,0,0];
    }).setOutput([100,100]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true);
    this.blankTex4 = this.gpu.createKernel(function(){
        return [0,0,0,0];
    }).setOutput([100,100]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true);
    this.blankTex1d = this.gpu.createKernel(function(a){
        return a;
    }).setOutput([100,100]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true);
    this.flatten = this.gpu.createKernel(function(input,insize){
        var i = this.thread.x;

        // var a = i%insize[0];
        // i = Math.floor(i/insize[0]);
        // var b = i%insize[1];
        // i = Math.floor(i/insize[1]);
        // var c = i%3;
        // i = Math.floor(i/3);

        var a = i%3;
        i = Math.floor(i/3);
        var b = i%insize[0];
        i = Math.floor(i/insize[0]);
        var c = i%insize[1];
        i = Math.floor(i/insize[1]);

        var out = input[c][b];
        return out[a];
    }).setOutput([100]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true);
    this.unflatten = this.gpu.createKernel(function(input,insize){
        var i = (this.thread.x+(this.thread.y*insize[0]))*3;
        return [input[i],input[i+1],input[i+2]];
    }).setOutput([100,100,100]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true);
    this.input = this.gpu.createKernel(function(input){
        return input[this.thread.x];
    }).setOutput([100]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true);
    this.concat = this.gpu.createKernel(function(a,b,l0){
        if (this.thread.x<l0){
            return a[this.thread.x];
        } else {
            return b[this.thread.x-l0];
        }
    }).setOutput([100]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true);
    // this.doNothing = this.gpu.createKernel(function(a){
    //     return a[this.thread.y][this.thread.x];
    // }).setOutput([100,100]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true);
    var self = this;
    var RCNN = function(ops) {
        this.VisionResolution = ops.VisionResolution;
        this.hasTwoEyes = ops.hasTwoEyes;
        this.layersKernelSizes = ops.layersKernelSizes;
        this.gpu = self.gpu;
        this.WaB = [];
        this.randomWaB = this.gpu.createKernel(function(m){
            function randn() {
                var u = 0, v = 0;
                while(u === 0) u = Math.random(); //Converting [0,1) to (0,1)
                while(v === 0) v = Math.random();
                return Math.sqrt( -2.0 * Math.log( u ) ) * Math.cos( 2.0 * Math.PI * v );
            }
            return [randn()*m, randn()*m, randn()*m];
            // if (this.thread.z < 3) {
            //     return [randn()*m, randn()*m, randn()*m];
            // } else {
            //     return [0,0,0];
            // }
        }).setOutput([100,100,6]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true);
        this.cycleLayer = this.gpu.createKernel(function(w0,inp,pre,kernelSize){
            var val = [0,0,0];
            var ksn = [-Math.floor(kernelSize[0]/2),-Math.floor(kernelSize[1]/2)];
            var ksx = [Math.ceil(kernelSize[0]/2)-1,Math.ceil(kernelSize[1]/2)-1];
            var Pos0 = [this.thread.y,this.thread.x];
            var Pos1 = [(this.thread.y*kernelSize[0])-ksn[0],(this.thread.x*kernelSize[1])-ksn[1]];
            for (var x = ksn[0]; x < ksx[0]; x++) {
                for (var y = ksn[1]; y < ksx[1]; y++) {
                    var Pos2 = [Pos1[0]+y,Pos1[1]+x];
                    var iptmp = inp[Pos2[0]][Pos2[1]];
                    var ip = [(iptmp[0]*2)-1,(iptmp[1]*2)-1,(iptmp[2]*2)-1];
                    val[0] += dt(ip,w0[0][Pos2[0]][Pos2[1]]);
                    val[1] += dt(ip,w0[1][Pos2[0]][Pos2[1]]);
                    val[2] += dt(ip,w0[2][Pos2[0]][Pos2[1]]);
                    ip = pre[Pos0[0]+y][Pos0[1]+x];
                    if (x == 0 && y == 0) {
                        var w = w0[3][Pos2[0]][Pos2[1]];
                        val[0] += w[1];
                        w = w0[4][Pos2[0]][Pos2[1]];
                        val[1] += w[1];
                        w = w0[5][Pos2[0]][Pos2[1]];
                        val[2] += w[1];
                    } else {
                        var w = w0[3][Pos0[0]+y][Pos0[1]+x];
                        val[0] += dt(ip,w);
                        w = w0[4][Pos0[0]+y][Pos0[1]+x];
                        val[1] += dt(ip,w);
                        w = w0[5][Pos0[0]+y][Pos0[1]+x];
                        val[2] += dt(ip,w);
                    }
                }
            }
            // var valtmp = inp[Pos1[0]][Pos1[1]];
            // var val = [(valtmp[0]*2)-1,(valtmp[1]*2)-1,(valtmp[2]*2)-1];
            val = act(val);
            return val;
        }).setOutput([100,100]).setDynamicOutput(true).setPipeline(true).setTactic('precision');
        this.backpropWaB = this.gpu.createKernel(function(delt,inp,prev,kernelSize){
            var ksn = [-Math.floor(kernelSize[0]/2),-Math.floor(kernelSize[1]/2)];
            var ksx = [Math.ceil(kernelSize[0]/2)-1,Math.ceil(kernelSize[1]/2)-1];
            var Pos0 = [this.thread.y,this.thread.x];
            var Pos1 = [Math.floor((this.thread.y)/kernelSize[1]),Math.floor((this.thread.x)/kernelSize[0])];
            var dlt = delt[Pos1[0]][Pos1[1]];
            // var div = curract[Pos1[0]][Pos1[1]];
            // var val = dlt[this.thread.z%3]*deriv1(div[this.thread.z%3]);
            var val = dlt[this.thread.z%3];
            // var val = (div[this.thread.z%3]);
            // var val = deriv1(div[this.thread.z%3]);
            var y = ((Pos1[0]*kernelSize[0])-Pos0[0])-ksn[0];
            var x = ((Pos1[1]*kernelSize[1])-Pos0[1])-ksn[1];
            // return [this.thread.x,this.thread.y,this.thread.z];
            if (this.thread.z < 3) {
                // return [0,0,0];
                var iptmp = inp[Pos0[0]][Pos0[1]];
                var ip = [(iptmp[0]*2)-1,(iptmp[1]*2)-1,(iptmp[2]*2)-1];
                return mul(ip,val);
            } else {
                // return [x,0,y];
                // var ip = prev[Pos1[0]+y][Pos1[1]+x];
                if (y == 0 && x == 0) {
                    return [val,val,val];
                    // return [0,0,0];
                } else {
                    var ip = prev[Pos1[0]-y][Pos1[1]-x];
                    // return [0,0,0];
                    return mul(ip,val);
                }
            }
        }).setOutput([100,100,6]).setDynamicOutput(true).setPipeline(true).setTactic('precision');
        this.addWaB = this.gpu.createKernel(function(a,b,c,m,kernelSize){
            // var Pos0 = [this.thread.y,this.thread.x];
            // var ksn = [-Math.floor(kernelSize[0]/2),-Math.floor(kernelSize[1]/2)];
            // var Pos1 = [Math.floor((this.thread.y)/kernelSize[1]),Math.floor((this.thread.x)/kernelSize[0])];
            // var y = ((Pos1[0]*kernelSize[0])-Pos0[0])-ksn[0];
            // var x = ((Pos1[1]*kernelSize[1])-Pos0[1])-ksn[1];
            // if (x == 0 && y == 0) {
            //     return ad(a[this.thread.z][this.thread.y][this.thread.x],mul(b[this.thread.z][this.thread.y][this.thread.x],m));
            // } else {
                return ad(a[this.thread.z][this.thread.y][this.thread.x],mul(b[this.thread.z][this.thread.y][this.thread.x],c));
            // }
        }).setOutput([100,100,6]).setDynamicOutput(true).setPipeline(true).setTactic('precision');
        this.blankTex = this.gpu.createKernel(function(){
            return [0,0,0];
        }).setOutput([100,100,6]).setDynamicOutput(true).setPipeline(true).setTactic('precision');
        this.findDelta = this.gpu.createKernel(function(acts,goal){
            var g = [goal[this.thread.y][this.thread.x][0],goal[this.thread.y][this.thread.x][1],goal[this.thread.y][this.thread.x][2]];
            return mult3(sub3(g,acts[this.thread.y][this.thread.x]),driv(acts[this.thread.y][this.thread.x]));
        }).setOutput([100,100]).setDynamicOutput(true).setPipeline(true).setTactic('precision');
        this.importWaB = this.gpu.createKernel(function(wFlat,insize){
            var i = (this.thread.x+((this.thread.y+(this.thread.z*insize[1]))*insize[0]))*3;
            return [wFlat[i],wFlat[i+1],wFlat[i+2]];
        }).setOutput([100,100,6]).setDynamicOutput(true).setPipeline(true).setTactic('precision');
        this.initalize = function() {
            this.activations = [];
            this.layerResolutions = [this.VisionResolution];
            this.NumberOfParamiters = 0;
            for (var i = 0; i < this.layersKernelSizes.length; i++) {
                this.layerResolutions.push([(this.layerResolutions[this.layerResolutions.length-1][0]-this.layersKernelSizes[i][0])/this.layersKernelSizes[i][0],(this.layerResolutions[this.layerResolutions.length-1][1]-this.layersKernelSizes[i][1])/this.layersKernelSizes[i][1]]);
            }
            this.WaB = [];
            this.WaBDelta = [];
            this.DataSetSize = 0;
            for (var i=0; i < this.layersKernelSizes.length; i++) {
                this.NumberOfParamiters += this.layersKernelSizes[i][0]*this.layersKernelSizes[i][1]*18;
                this.NumberOfNeurons += this.layerResolutions[i+1][0]*this.layerResolutions[i+1][1]*3;
                self.blankTex.setOutput(this.layerResolutions[i+1]);
                this.activations.push(self.blankTex().clone());
                this.randomWaB.setOutput(this.layerResolutions[i].concat([6]));
                var m = 0.9/Math.sqrt(this.layersKernelSizes[i][0]*this.layersKernelSizes[i][1]*6);
                this.WaB.push(this.randomWaB(m).clone());
                this.blankTex.setOutput(this.layerResolutions[i].concat([6]));
                // console.log(this.layerResolutions[i].concat([6]));
                this.WaBDelta.push(this.blankTex().clone());
            }
            this.outpSize = this.layerResolutions[this.layerResolutions.length-1];
        }
        this.cycle = function(inp) {
            var inpf = inp;
            for (var i = 0; i < this.layersKernelSizes.length; i++) {
                this.cycleLayer.setOutput(this.layerResolutions[i+1]);
                inpf = this.cycleLayer(this.WaB[i],inpf,this.activations[i],this.layersKernelSizes[i]).clone();
                this.activations[i] = inpf;
            }
        }
        this.train = function(inp,goal) {
            this.findDelta.setOutput(this.layerResolutions[this.layerResolutions.length-1]);
            var prev = this.activations.slice();
            this.cycle(inp);
            this.DataSetSize++;
            var grad = this.findDelta(this.activations[this.activations.length-1],goal);
            this.backpropWaB.setOutput(this.layerResolutions[0].concat([6]));
            this.addWaB.setOutput(this.layerResolutions[0].concat([6]));
            this.WaBDelta[0] = this.addWaB(this.WaBDelta[0],this.backpropWaB(grad,inp,prev[0],this.layersKernelSizes[0]),1,1,this.layersKernelSizes[0]).clone();
        }
        this.trainDeltaWithPrev = function(inp,delta,prev) {
            this.DataSetSize++;
            var grad = delta;
            this.backpropWaB.setOutput(this.layerResolutions[0].concat([6]));
            this.addWaB.setOutput(this.layerResolutions[0].concat([6]));
            this.WaBDelta[0] = this.addWaB(this.WaBDelta[0],this.backpropWaB(grad,inp,prev[0],this.layersKernelSizes[0]),1,1,this.layersKernelSizes[0]).clone();
        }
        this.finishEpoch = function(lr) {
            this.addWaB.setOutput(this.layerResolutions[0].concat([6]));
            // this.WaB[0] = this.addWaB(this.WaB[0],this.WaBDelta[0],lr/this.DataSetSize).clone();
            this.WaB[0] = this.addWaB(this.WaB[0],this.WaBDelta[0],lr/(this.DataSetSize*Math.sqrt(this.layersKernelSizes[0][0]*this.layersKernelSizes[0][1]*6)),lr/this.DataSetSize,this.layersKernelSizes[0]).clone();
            self.blankTex.setOutput(this.layerResolutions[0].concat([6]));
            this.WaBDelta[0] = this.blankTex().clone();
            this.DataSetSize = 0;
        }
        this.Import = function(wab) {
            this.importWaB.setOutput(this.layerResolutions[0].concat([6]));
            this.WaB[0] = this.importWaB(wab,this.layerResolutions[0].concat([6])).clone();
        }
        this.resetZeros = function() {
            self.blankTex.setOutput(this.layerResolutions[1]);
            this.activations[0] = self.blankTex().clone();
        }
    }
    this.RCNN = new RCNN(this.opts.Vision);
    this.RCNN.initalize();
    // console.log(this.RCNN);
    var RNN = function(ops) {
        this.gpu = self.gpu;
        this.layers = ops.layers;
        this.inpSize = ops.inpSize;
        this.inpShape = ops.inpShape;
        this.ExtraInpSize = ops.ExtraInpSize;
        this.fullInpSize = this.inpSize+this.ExtraInpSize;
        this.randomWaB = this.gpu.createKernel(function(m,l){
            function randn() {
                var u = 0, v = 0;
                while(u === 0) u = Math.random(); //Converting [0,1) to (0,1)
                while(v === 0) v = Math.random();
                return Math.sqrt( -2.0 * Math.log( u ) ) * Math.cos( 2.0 * Math.PI * v );
            }
            return randn()*m;
            // if (this.thread.y < l && this.thread.y > 0) {
            //     return randn()*m;
            // } else {
            //     return 0;
            // }
        }).setOutput([100,100]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true);
        // this.RCNNcycleLayer = this.gpu.createKernel(function(WaB,inp,prev,l0,l1) {
        //     var x = this.thread.x;
        //     var val = WaB[0][x];
        //     for (var i = 0; i < l0; i++) {
        //         val += inp[i]*WaB[i+1][x];
        //     }
        //     for (var i2 = 0; i2 < l1; i2++) {
        //         val += prev[i2]*WaB[i2+l0+1][x];
        //     }
        //     return act1(val);
        // }).setOutput([100]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true);
        this.RNNcycleLayerFunction = function(WaB,inp,prev,l0,l1) {
            var x = this.thread.x;
            var val = WaB[0][x];
            for (var i = 0; i < l0; i++) {
                val += inp[i]*WaB[i+1][x];
            }
            for (var i2 = 0; i2 < l1; i2++) {
                val += prev[i2]*WaB[i2+l0+1][x];
            }
            return act1(val);
        }
        this.blankAct = this.gpu.createKernel(function() {
            return 0;
        }).setOutput([100]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true);
        this.blankWaB = this.gpu.createKernel(function() {
            return 0;
        }).setOutput([100,100]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true);
        this.findDelta = this.gpu.createKernel(function(out,goal) {
            return (goal[this.thread.x]-out[this.thread.x])*driv1(out[this.thread.x]);
        }).setOutput([100]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true);
        // this.backprop = this.gpu.createKernel(function(delta,W,acts,l0) {
        //     var val = delta[this.thread.x];
        //     for (var i = 0; i < l0; i++) {
        //         val += delta[i]*W[this.thread.x+1][i];
        //     }
        //     return val*driv1(acts[this.thread.x]);
        // }).setOutput([100]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true);
        this.backpropFunction = function(delta,W,acts,l0) {
            var val = 0;
            for (var i = 0; i < l0; i++) {
                val += delta[i]*W[this.thread.x+1][i];
            }
            return val*driv1(acts[this.thread.x]);
        }
        this.addWaB = this.gpu.createKernel(function(WaB,delta,lr,m) {
            // if (this.thread.y == 0) {
            //     return WaB[this.thread.y][this.thread.x] + delta[this.thread.y][this.thread.x]*m;
            // } else {
                return WaB[this.thread.y][this.thread.x] + delta[this.thread.y][this.thread.x]*lr;
            // }
        }).setOutput([100]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true);
        this.importWaB = this.gpu.createKernel(function(wab,len) {
            return wab[this.thread.x+(this.thread.y*len)];
        }).setOutput([100,100]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true);
        this.backpropWaB = this.gpu.createKernel(function(delta,inp,prev,l0) {
            var val = delta[this.thread.x];
            if (this.thread.y == 0) {
                return val;
            } else {
                if (this.thread.y < l0) {
                    return val*inp[this.thread.y-1];
                } else {
                    return val*prev[this.thread.y-l0];
                }
            }
        }).setOutput([100,100]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true);
        this.initalize = function() {
            this.WaB = [];
            this.WaBDelta = [];
            this.activations = [];
            this.CycleLayerFunctions = [];
            this.BackpropLayerFunctions = [];
            this.NumberOfParamiters = (this.layers[0]+this.fullInpSize+1)*this.layers[0];
            this.DataSetSize = 0;
            for (var i = 0; i < this.layers.length; i++) {
                if (i == 0) {
                    // var m = 1/Math.sqrt(this.layers[i]+this.fullInpSize+1);
                    var m = 1/Math.sqrt(this.fullInpSize);
                    this.randomWaB.setOutput([this.layers[i],this.layers[i]+this.fullInpSize+1]);
                    console.log([this.layers[i],this.layers[i]+this.fullInpSize+1]);
                    // this.WaB.push(this.randomWaB(m).clone());
                    this.WaB.push(this.randomWaB(m,this.fullInpSize+1).clone());
                    this.blankWaB.setOutput([this.layers[i],this.layers[i]+this.fullInpSize+1]);
                    this.WaBDelta.push(this.blankWaB().clone());
                    this.blankAct.setOutput([this.layers[i]]);
                    this.activations.push(this.blankAct().clone());
                    this.CycleLayerFunctions.push(this.gpu.createKernel(this.RNNcycleLayerFunction).setOutput([this.layers[i]]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true));
                    this.BackpropLayerFunctions.push(this.gpu.createKernel(this.backpropFunction).setOutput([this.inpSize]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true));
                } else {
                    this.NumberOfParamiters += (this.layers[i]+this.layers[i-1]+1)*this.layers[i];
                    // var m = 1/Math.sqrt(this.layers[i]+this.layers[i-1]+1);
                    var m = 1/Math.sqrt(this.layers[i-1]);
                    this.randomWaB.setOutput([this.layers[i],this.layers[i]+this.layers[i-1]+1]);
                    console.log([this.layers[i],this.layers[i]+this.layers[i-1]+1]);
                    // this.WaB.push(this.randomWaB(m).clone());
                    this.WaB.push(this.randomWaB(m,this.layers[i-1]+1).clone());
                    this.blankWaB.setOutput([this.layers[i],this.layers[i]+this.layers[i-1]+1]);
                    this.WaBDelta.push(this.blankWaB().clone());
                    this.blankAct.setOutput([this.layers[i]]);
                    this.activations.push(this.blankAct().clone());
                    this.CycleLayerFunctions.push(this.gpu.createKernel(this.RNNcycleLayerFunction).setOutput([this.layers[i]]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true));
                    this.BackpropLayerFunctions.push(this.gpu.createKernel(this.backpropFunction).setOutput([this.layers[i-1]]).setDynamicOutput(true).setPipeline(true).setTactic('precision').setImmutable(true));
                }
            }
            this.DataSetSize = 0;
        }
        this.cycleFlatConcated = function(flattenedAndConcatedInput) {
            for (var i = 0; i < this.layers.length; i++) {
                if (i == 0) {
                    this.activations[i] = this.CycleLayerFunctions[i](this.WaB[0],flattenedAndConcatedInput,this.activations[0],this.fullInpSize,this.layers[0]);
                } else {
                    this.activations[i] = this.CycleLayerFunctions[i](this.WaB[i],this.activations[i-1],this.activations[i],this.layers[i-1],this.layers[i]);
                }
            }
        }
        this.cycleFlat = function(inp,inpex) {
            self.concat.setOutput([this.fullInpSize]);
            var inpf = self.concat(inp,inpex,this.inpSize);
            this.cycleFlatConcated(inpf);
        }
        this.cycle = function(inp,inpex) {
            self.flatten.setOutput([this.inpSize]);
            var inpf = self.flatten(inp,this.inpShape);
            this.cycleFlat(inpf,inpex);
        }
        this.trainDelta = function(inp,inpe,delta,isout) {
            self.flatten.setOutput([this.inpSize]);
            self.concat.setOutput([this.fullInpSize]);
            var inpf = self.concat(self.flatten(inp,this.inpShape),inpe,this.inpSize);
            var prev = this.activations.slice();
            this.cycleFlatConcated(inpf);
            for (var i = this.layers.length-1; i > 0; i--) {
                this.addWaB.setOutput([this.layers[i],this.layers[i]+this.layers[i-1]+1]);
                this.backpropWaB.setOutput([this.layers[i],this.layers[i]+this.layers[i-1]+1]);
                this.WaBDelta[i] = this.addWaB(this.WaBDelta[i],this.backpropWaB(delta,this.activations[i-1],prev[i],this.layers[i-1]),1,1).clone();

                delta = this.BackpropLayerFunctions[i](delta,this.WaB[i],this.activations[i-1],this.layers[i]);
                // console.log(delta.toArray());
            }
            this.addWaB.setOutput([this.layers[0],this.layers[0]+this.fullInpSize+1]);
            this.backpropWaB.setOutput([this.layers[0],this.layers[0]+this.fullInpSize+1]);
            this.WaBDelta[0] = this.addWaB(this.WaBDelta[0],this.backpropWaB(delta,inpf,prev[0],this.fullInpSize),1,1).clone();
            this.DataSetSize++;
            for (var i = 0; i < this.layers.length; i++) {
                prev[i].delete();
            }
            if (isout) {
                return this.BackpropLayerFunctions[0](delta,this.WaB[0],inpf,this.layers[0]);
            }
        }
        this.train = function(inp,inpe,g,isout) {
            this.findDelta.setOutput([this.layers[this.layers.length-1]]);
            var delta = this.findDelta(this.activations[this.layers.length-1],g);
            return this.trainDelta(inp,inpe,delta,isout);
        }
        this.finishEpoch = function(lr) {
            for (var i = 0; i < this.layers.length; i++) {
                if (i == 0) {
                    this.addWaB.setOutput([this.layers[i],this.layers[i]+this.fullInpSize+1]);
                    // this.WaB[i] = this.addWaB(this.WaB[i],this.WaBDelta[i],lr/this.DataSetSize).clone();
                    this.WaB[i] = this.addWaB(this.WaB[i],this.WaBDelta[i],lr/(this.DataSetSize*Math.sqrt(this.layers[i]+this.fullInpSize)),lr/this.DataSetSize).clone();
                    // this.blankWaB.setOutput([this.layers[i],this.layers[i]+this.fullInpSize+1]);
                    // this.WaBDelta[i] = this.blankWaB().clone();
                    this.WaBDelta[i].clear();
                } else {
                    this.addWaB.setOutput([this.layers[i],this.layers[i]+this.layers[i-1]+1]);
                    // this.WaB[i] = this.addWaB(this.WaB[i],this.WaBDelta[i],lr/this.DataSetSize).clone();
                    this.WaB[i] = this.addWaB(this.WaB[i],this.WaBDelta[i],lr/(this.DataSetSize*Math.sqrt(this.layers[i]+this.layers[i-1])),lr/this.DataSetSize).clone();
                    // this.blankWaB.setOutput([this.layers[i],this.layers[i]+this.layers[i-1]+1]);
                    // this.WaBDelta[i] = this.blankWaB().clone();
                    this.WaBDelta[i].clear();
                }
            }
            this.DataSetSize = 0;
        }
        this.Import = function(data,lyr) {
            if (lyr == 0) {
                this.importWaB.setOutput([this.layers[lyr],this.layers[lyr]+this.fullInpSize+1]);
                this.WaB[lyr] = this.importWaB(data,this.layers[lyr]).clone();
            } else {
                this.importWaB.setOutput([this.layers[lyr],this.layers[lyr]+this.layers[lyr-1]+1]);
                this.WaB[lyr] = this.importWaB(data,this.layers[lyr]).clone();
            }
        }
        this.resetZeros = function() {
            for (var i = 0; i < this.layers.length; i++) {
                this.activations[i].clear();
            }
        }
    }
    this.opts.Brain.inpSize = this.RCNN.outpSize[0]*this.RCNN.outpSize[1]*3;
    this.opts.Brain.inpShape = this.RCNN.outpSize;
    this.opts.Brain.ExtraInpSize = this.opts.Brain.ExtraInputs;
    this.RNN = new RNN(this.opts.Brain);
    this.RNN.initalize();
    this.NumberOfParamiters = this.RNN.NumberOfParamiters+this.RCNN.NumberOfParamiters;
    this.NumberOfNeurons = this.RCNN.NumberOfNeurons+this.RNN.NumberOfNeurons;
    this.train = function(inputData,exinp,targetData,returnloss,returnGradient) {
        var rcnn = this.RCNN.activations.slice();
        this.RCNN.cycle(inputData);
        var grad = this.RNN.train(this.RCNN.activations[this.RCNN.activations.length-1],exinp,targetData,true);
        this.unflatten.setOutput(this.RCNN.outpSize);
        grad = this.unflatten(grad,this.RCNN.outpSize).clone();
        this.RCNN.trainDeltaWithPrev(inputData,grad,rcnn);
        for (var i=0; i<this.RCNN.activations.length; i++) {
            rcnn[i].delete();
        }
        if (returnloss) {
            // console.log(this.RNN.activations[this.RNN.activations.length-1].toArray());
            var actsout = this.RNN.activations[this.RNN.activations.length-1].toArray();
            var loss = actsout.map(function(x,ix){return (x-targetData[ix])**2}).reduce(function(a,b) {return a+b;})/(this.RNN.layers[this.RNN.layers.length-1]*2);
            if (returnGradient) {
                return {Gradient: grad,loss:loss};
            } else {
                grad.delete();
                return {loss:loss};
            }
            // return grad;
        }
    }
    this.finishEpoch = function(lr) {
        this.RNN.finishEpoch(lr);
        this.RCNN.finishEpoch(lr);
        // this.RCNN.finishEpoch(0);
    }
    this.cycle = function(inptTex,aud) {
        this.RCNN.cycle(inptTex);
        this.RNN.cycle(this.RCNN.activations[this.RCNN.activations.length-1],aud);
    }
    this.FToffsets = [];
    var PIover2 = Math.PI/2;
    this.FT = function(timeDomain,len,m) {
        var freqDomain = [];
        m = m || 1;
        for (var i = 0; i < len; i++) {
            var x = 0;
            var y = 0;
            var r = i*m*2*Math.PI/timeDomain.length;
            for (var j = 0; j < timeDomain.length; j++) {
                x += timeDomain[j]*Math.cos(j*r);
                y += timeDomain[j]*Math.sin(j*r);
            }
            // freqDomain.push([x,y]);
            freqDomain.push(Math.hypot(x,y));
        }
        return freqDomain;
    }
    this.FTProcessed = function(timeDomain,len,m) {
        var freqDomain = [];
        m = m || 1;
        for (var i = 0; i < len; i++) {
            var x = 0;
            var y = 0;
            var r = i*m*2*Math.PI/timeDomain.length;
            for (var j = 0; j < timeDomain.length; j++) {
                x += timeDomain[j]*Math.cos(j*r);
                y += timeDomain[j]*Math.sin(j*r);
            }
            // freqDomain.push([x,y]);
            freqDomain.push(Math.hypot(x,y));
        }
        return this.Process(freqDomain);
    }
    this.Process = function(dat) {
        return dat.map(function(x,ix){
            x = Math.exp(-2*((((x/8)*(Math.exp((PIover2*ix/dat.length)**2)))-1)));
            return (1-x)/(1+x);
        });
    }
    this.unProcess = function(dat) {
        return dat.map(function(x,ix){return 8*((-0.5*Math.log((2/(x+1))-1)+1)/(Math.exp((PIover2*ix/dat.length)**2)))});
    }
    this.InverseFT = function(freqDomain,FrqLen,len) {
        var timeDomain = new Float32Array(len).fill(0);
        for (var i = 0; i < len; i++) {
            var x = 0;
            // var y = 0;
            var r = 2*i*Math.PI/FrqLen;
            var falloff = Math.min(1,(len-i)/200)*Math.min(1,i/200);
            for (var j = 0; j < freqDomain.length; j++) {
                // x += freqDomain[j]*Math.sin(this.FToffsets[i]);
                x += freqDomain[j]*Math.sin(j*r)*falloff;
                // if (!this.FToffsets[i]) {
                //     this.FToffsets[i] = r;
                // }
                // this.FToffsets[i] = (r+this.FToffsets[i])%(2*Math.PI);
                // y += freqDomain[j][1]*Math.sin(j*r);
            }
            // timeDomain.push(Math.sqrt(x**2+y**2));
            timeDomain[i] = (2*x/FrqLen);
        }
        return timeDomain;
    }
    this.runNetwork = function(VisionInp,Audio) {
        this.cycle(VisionInp,Audio);
        var out = this.RNN.activations[this.RNN.activations.length-1].toArray();
        return this.parseNetworkOutput(out);
    }
    this.resetZeros = function() {
        this.RNN.resetZeros();
        this.RCNN.resetZeros();
    }
    this.parseNetworkOutput = function(data) {
        return {Audio:data.slice(0,128),Motion:this.ArrayToMoCap(data.slice(128,184))};
    }
    this.MoCapToArray = function(cap) {
        var arr = [];
        arr = arr.concat(Array.from(cap.Head.translation).map(function(x) {return x/2}));
        arr = arr.concat(Array.from(cap.Head.rotation));
        arr = arr.concat(Array.from(cap.LeftHand.translation).map(function(x) {return x/2}));
        arr = arr.concat(Array.from(cap.LeftHand.rotation));
        arr = arr.concat(Array.from(cap.RightHand.translation).map(function(x) {return x/2}));
        arr = arr.concat(Array.from(cap.RightHand.rotation));
        arr = arr.concat(Array.from(cap.Hip.translation).map(function(x) {return x/2}));
        arr = arr.concat(Array.from(cap.Hip.rotation));
        arr = arr.concat(Array.from(cap.LeftFoot.translation).map(function(x) {return x/2}));
        arr = arr.concat(Array.from(cap.LeftFoot.rotation));
        arr = arr.concat(Array.from(cap.RightFoot.translation).map(function(x) {return x/2}));
        arr = arr.concat(Array.from(cap.RightFoot.rotation));
        arr = arr.concat(Array.from(cap.RightControler.Joystick));
        arr.push((cap.RightControler.Grip*2)-1);
        arr.push((cap.RightControler.Trigger*2)-1);
        arr.push([-1,1][+cap.RightControler.Abutton]);
        arr.push([-1,1][+cap.RightControler.Bbutton]);
        arr.push([-1,1][+cap.RightControler.JoystickButton]);
        arr = arr.concat(Array.from(cap.LeftControler.Joystick));
        arr.push((cap.LeftControler.Grip*2)-1);
        arr.push((cap.LeftControler.Trigger*2)-1);
        arr.push([-1,1][+cap.LeftControler.Xbutton]);
        arr.push([-1,1][+cap.LeftControler.Ybutton]);
        arr.push([-1,1][+cap.LeftControler.JoystickButton]);
        return arr;
    }
    this.ArrayToMoCap = function(arr) {
        var out = {
            Head:{
                translation:new Float32Array(3).fill(0),
                rotation:new Float32Array(4).fill(0)
            },
            LeftHand:{
                translation:new Float32Array(3).fill(0),
                rotation:new Float32Array(4).fill(0)
            },
            RightHand:{
                translation:new Float32Array(3).fill(0),
                rotation:new Float32Array(4).fill(0)
            },
            Hip:{
                translation:new Float32Array(3).fill(0),
                rotation:new Float32Array(4).fill(0)
            },
            LeftFoot:{
                translation:new Float32Array(3).fill(0),
                rotation:new Float32Array(4).fill(0)
            },
            RightFoot:{
                translation:new Float32Array(3).fill(0),
                rotation:new Float32Array(4).fill(0)
            },
            RightControler:{
                Joystick:new Float32Array(2).fill(0),
                Grip:0,
                Trigger:0,
                Abutton:0,
                Bbutton:0,
                JoystickButton:0
            },
            LeftControler:{
                Joystick:new Float32Array(2).fill(0),
                Grip:0,
                Trigger:0,
                Xbutton:0,
                Ybutton:0,
                JoystickButton:0
            }
        };
        out.Head.translation[0] = arr[0]*2;
        out.Head.translation[1] = arr[1]*2;
        out.Head.translation[2] = arr[2]*2;
        out.Head.rotation[0] = arr[3];
        out.Head.rotation[1] = arr[4];
        out.Head.rotation[2] = arr[5];
        out.Head.rotation[3] = arr[6];
        out.LeftHand.translation[0] = arr[7]*2;
        out.LeftHand.translation[1] = arr[8]*2;
        out.LeftHand.translation[2] = arr[9]*2;
        out.LeftHand.rotation[0] = arr[10];
        out.LeftHand.rotation[1] = arr[11];
        out.LeftHand.rotation[2] = arr[12];
        out.LeftHand.rotation[3] = arr[13];
        out.RightHand.translation[0] = arr[14]*2;
        out.RightHand.translation[1] = arr[15]*2;
        out.RightHand.translation[2] = arr[16]*2;
        out.RightHand.rotation[0] = arr[17];
        out.RightHand.rotation[1] = arr[18];
        out.RightHand.rotation[2] = arr[19];
        out.RightHand.rotation[3] = arr[20];
        out.Hip.translation[0] = arr[21]*2;
        out.Hip.translation[1] = arr[22]*2;
        out.Hip.translation[2] = arr[23]*2;
        out.Hip.rotation[0] = arr[24];
        out.Hip.rotation[1] = arr[25];
        out.Hip.rotation[2] = arr[26];
        out.Hip.rotation[3] = arr[27];
        out.LeftFoot.translation[0] = arr[28]*2;
        out.LeftFoot.translation[1] = arr[29]*2;
        out.LeftFoot.translation[2] = arr[30]*2;
        out.LeftFoot.rotation[0] = arr[31];
        out.LeftFoot.rotation[1] = arr[32];
        out.LeftFoot.rotation[2] = arr[33];
        out.LeftFoot.rotation[3] = arr[34];
        out.RightFoot.translation[0] = arr[35]*2;
        out.RightFoot.translation[1] = arr[36]*2;
        out.RightFoot.translation[2] = arr[37]*2;
        out.RightFoot.rotation[0] = arr[38];
        out.RightFoot.rotation[1] = arr[39];
        out.RightFoot.rotation[2] = arr[40];
        out.RightFoot.rotation[3] = arr[41];
        out.RightControler.Joystick[0] = arr[42];
        out.RightControler.Joystick[1] = arr[43];
        out.RightControler.Grip = (arr[44]+1)/2;
        out.RightControler.Trigger = (arr[45]+1)/2;
        out.RightControler.Abutton = arr[46]>0;
        out.RightControler.Bbutton = arr[47]>0;
        out.RightControler.JoystickButton = arr[48]>0;
        out.LeftControler.Joystick[0] = arr[49];
        out.LeftControler.Joystick[1] = arr[50];
        out.LeftControler.Grip = (arr[51]+1)/2;
        out.LeftControler.Trigger = (arr[52]+1)/2;
        out.LeftControler.Xbutton = arr[53]>0;
        out.LeftControler.Ybutton = arr[54]>0;
        out.LeftControler.JoystickButton = arr[55]>0;
        return out;
    }
    this.Export = function() {
        var Arr = [];
        var ArrTmp = this.RCNN.WaB[0].toArray();
        for (var i=0; i<ArrTmp.length; i++) {
            for (var j=0; j<ArrTmp[i].length; j++) {
                for (var k=0; k<ArrTmp[i][j].length; k++) {
                    Arr.push(ArrTmp[i][j][k][0], ArrTmp[i][j][k][1], ArrTmp[i][j][k][2]);
                }
            }
        }
        for (var i=0; i<this.RNN.WaB.length; i++) {
            ArrTmp = this.RNN.WaB[i].toArray();
            for (var j=0; j<ArrTmp.length; j++) {
                for (var k=0; k<ArrTmp[j].length; k++) {
                    Arr.push(ArrTmp[j][k]);
                }
            }
        }
        return new Uint8Array(new Float32Array(Arr).buffer);
    }
    this.Import = function(Arr) {
        var idx = 0;
        this.RCNN.Import(Arr.slice(0,this.RCNN.layerResolutions[0][0]*this.RCNN.layerResolutions[0][1]*18));
        // console.log(this.RCNN.WaB[0].toArray());
        idx += this.RCNN.layerResolutions[0][0]*this.RCNN.layerResolutions[0][1]*18;
        for (var i=0; i<this.RNN.WaB.length; i++) {
            if (i==0) {
                this.RNN.Import(Arr.slice(idx,idx+((this.RNN.layers[i]+this.RNN.fullInpSize+1)*this.RNN.layers[i])),i);
                idx += (this.RNN.layers[i]+this.RNN.fullInpSize+1)*this.RNN.layers[i];
            } else {
                this.RNN.Import(Arr.slice(idx,idx+((this.RNN.layers[i]+this.RNN.layers[i-1]+1)*this.RNN.layers[i])),i);
                idx += (this.RNN.layers[i]+this.RNN.layers[i-1]+1)*this.RNN.layers[i];
            }
        }
    }
}