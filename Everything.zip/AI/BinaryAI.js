var BinAI = function(opts){
    this.opts = opts;
	var self = this;
	this.RandomConection = function() {
		function rnd(i) {
			if (i <= 1) {
				return [Math.round(Math.random()),Math.round(Math.random())];
				//return [Math.round(Math.random()/1.5),Math.round(Math.random()/1.5)];
				//return [0,0];
			} else {
				return [rnd(i-1),rnd(i-1)];
			}
		}
		return rnd(8);
	}
	this.ZerosConection = function() {
		function rnd(i) {
			if (i <= 1) {
				return [0,0];
				//return [0,0];
			} else {
				return [rnd(i-1),rnd(i-1)];
			}
		}
		return rnd(8);
	}
	this.OnesConection = function() {
		function rnd(i) {
			if (i <= 1) {
				return [0,0];
				//return [0,0];
			} else {
				return [rnd(i-1),rnd(i-1)];
			}
		}
		return rnd(8);
	}
	this.getBit = function(v,b) {
		return v[b[0]][b[1]][b[2]][b[3]][b[4]][b[5]][b[6]][b[7]];
	}
	this.PositiveMod = function(x,m) {
		return ((x%m)+m)%m;
		//return Math.max(Math.min(x,m-1),0);
	}
    this.Activations = new Array(opts.h).fill([]).map(function(){return new Array(opts.w).fill(0)});
	//this.Activations = new Array(opts.h).fill([]).map(function(){return new Array(opts.w).fill(0).map(function(){return Math.round(Math.random())})});
	this.ActivationsPrev = this.Activations;
	this.NeuronBits = new Array(opts.h).fill([]).map(function(){return new Array(opts.w).fill([0,0,0,0,0,0,0,0])});
	this.NeuronBitsPrev = new Array(opts.h).fill([]).map(function(){return new Array(opts.w).fill([0,0,0,0,0,0,0,0])});
	this.Goal = new Array(opts.h).fill([]).map(function(){return new Array(opts.w).fill(0)});
	this.Conections = new Array(opts.h).fill([]).map(function(){return new Array(opts.w).fill(0).map(self.RandomConection)});
	//this.Sums = new Array(opts.h).fill([]).map(function(){return new Array(opts.w).fill(0).map(self.OnesConection)});
	this.InputX = Math.floor((opts.w-opts.InputSize)/2);
	this.InputSize = opts.InputSize;
	this.InputY = Math.floor(opts.h/2);
	this.Sums = new Array(opts.h).fill([]).map(function(){return new Array(opts.w).fill(0)});
	this.calculateNeuronBits = function(x,y) {
		return [
			self.Activations[self.PositiveMod(y-1,self.opts.h)][self.PositiveMod(x-1,self.opts.w)],
			self.Activations[self.PositiveMod(y-1,self.opts.h)][x],
			self.Activations[self.PositiveMod(y-1,self.opts.h)][self.PositiveMod(x+1,self.opts.w)],
			self.Activations[y][self.PositiveMod(x-1,self.opts.w)],
			self.Activations[y][self.PositiveMod(x+1,self.opts.w)],
			self.Activations[self.PositiveMod(y+1,self.opts.h)][self.PositiveMod(x-1,self.opts.w)],
			self.Activations[self.PositiveMod(y+1,self.opts.h)][x],
			self.Activations[self.PositiveMod(y+1,self.opts.h)][self.PositiveMod(x+1,self.opts.w)],
		];
	}
	this.writeBit = function(n,b,v) {
		n[b[0]][b[1]][b[2]][b[3]][b[4]][b[5]][b[6]][b[7]] = v;
	}
	this.cycle = function(inp) {
		var newActs = [];
		for (var y=0; y<self.opts.h; y++) {
			newActs[y] = [];
			for (var x=0; x<self.opts.w; x++) {
				self.NeuronBitsPrev[y][x] = self.calculateNeuronBits(x,y);
				newActs[y][x] = self.getBit(this.Conections[y][x],self.NeuronBits[y][x]);
			}
		}
		var tmp = self.NeuronBits;
		self.NeuronBits = self.NeuronBitsPrev;
		self.NeuronBitsPrev = tmp;
		tmp = self.Activations;
		self.Activations = newActs;
		self.ActivationsPrev = tmp;
	}
	this.intTobyte = function(n) {
		return [
			n%2,
			Math.floor(n/2)%2,
			Math.floor(n/4)%2,
			Math.floor(n/8)%2,
			Math.floor(n/16)%2,
			Math.floor(n/32)%2,
			Math.floor(n/64)%2,
			Math.floor(n/128)%2
		];
	}
	this.simularity = function(a,b) {
		return ((a[0]==b[0])+(a[1]==b[1])+(a[2]==b[2])+(a[3]==b[3])+(a[4]==b[4])+(a[5]==b[5])+(a[6]==b[6])+(a[7]==b[7]));
	}
	this.train = function(inp,outp) {
		var acc = 0;
		function backprop() {
			var newGoal = new Array(self.opts.h).fill(0).map(function(){return new Array(self.opts.w).fill(0)});
			//var newGoal = self.Goal;
			for (var y=0; y<self.opts.h; y++) {
				for (var x=0; x<self.opts.w; x++) {
					var v = self.Goal[y][x];
					var a = self.Activations[y][x];
					var g = (v === 0) ? a : +(v > 0);
					//var g = (Math.abs(v) <= 0) ? self.Activations[y][x] : +(v > 0);
					//a = self.ActivationsPrev[y][x];
					if (a !== g) {
						var b = new Array(8).fill(0);
						for (var i=0; i<256; i++) {
							var bits = self.intTobyte(i);
							if (self.getBit(self.Conections[y][x],bits) === g) {
								//if (self.simularity(self.NeuronBitsPrev[y][x],bits) >= 4) {
									b[0] += (bits[0]*2)-1;
									b[1] += (bits[1]*2)-1;
									b[2] += (bits[2]*2)-1;
									b[3] += (bits[3]*2)-1;
									b[4] += (bits[4]*2)-1;
									b[5] += (bits[5]*2)-1;
									b[6] += (bits[6]*2)-1;
									b[7] += (bits[7]*2)-1;
								//}
							}
						}
						newGoal[self.PositiveMod(y-1,self.opts.h)][self.PositiveMod(x-1,self.opts.w)] += Math.sign(b[0]);
						newGoal[self.PositiveMod(y-1,self.opts.h)][x] += Math.sign(b[1]);
						newGoal[self.PositiveMod(y-1,self.opts.h)][self.PositiveMod(x+1,self.opts.w)] += Math.sign(b[2]);
						newGoal[y][self.PositiveMod(x-1,self.opts.w)] += Math.sign(b[3]);
						newGoal[y][self.PositiveMod(x+1,self.opts.w)] += Math.sign(b[4]);
						newGoal[self.PositiveMod(y+1,self.opts.h)][self.PositiveMod(x-1,self.opts.w)] += Math.sign(b[5]);
						newGoal[self.PositiveMod(y+1,self.opts.h)][x] += Math.sign(b[6]);
						newGoal[self.PositiveMod(y+1,self.opts.h)][self.PositiveMod(x+1,self.opts.w)] += Math.sign(b[7]);
						b = self.NeuronBitsPrev[y][x];
						self.Conections[y][x][b[0]][b[1]][b[2]][b[3]][b[4]][b[5]][b[6]][b[7]] = g;
					}
					if (true) {
						var b = self.NeuronBits[y][x];
						newGoal[self.PositiveMod(y-1,self.opts.h)][self.PositiveMod(x-1,self.opts.w)] += (b[0]*2)-1;
						newGoal[self.PositiveMod(y-1,self.opts.h)][x] += (b[1]*2)-1;
						newGoal[self.PositiveMod(y-1,self.opts.h)][self.PositiveMod(x+1,self.opts.w)] += (b[2]*2)-1;
						newGoal[y][self.PositiveMod(x-1,self.opts.w)] += (b[3]*2)-1;
						newGoal[y][self.PositiveMod(x+1,self.opts.w)] += (b[4]*2)-1;
						newGoal[self.PositiveMod(y+1,self.opts.h)][self.PositiveMod(x-1,self.opts.w)] += (b[5]*2)-1;
						newGoal[self.PositiveMod(y+1,self.opts.h)][x] += (b[6]*2)-1;
						newGoal[self.PositiveMod(y+1,self.opts.h)][self.PositiveMod(x+1,self.opts.w)] += (b[7]*2)-1;
					}
				}
			}
			//console.log(newGoal);
			self.Goal = newGoal;
		}
		//for (var idx=0; idx<outp.length; idx++) {
			self.cycle(inp);
			for (var i=0; i<outp.length; i++) {
				self.Goal[0][i] = (outp[i]*16)-8;
				acc+=(self.Activations[0][i] == outp[i])/outp.length;
			}
			backprop();
		//}
		//acc /= outp.length;
		//console.log(acc);
		return {Grad:self.Goal,Acc:acc};
	}
}






